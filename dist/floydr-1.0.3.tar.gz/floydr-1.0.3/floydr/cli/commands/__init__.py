"""CLI commands for Flicky."""

from .create import create_widget

__all__ = ["create_widget"]

